const QUESTIONS = [
  {
    "type": "mcq",
    "question": "Choose the proper noun.",
    "options": [
      "city",
      "teacher",
      "London",
      "book"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which is a common noun?",
    "options": [
      "Africa",
      "Monday",
      "doctor",
      "Sarah"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which noun is countable?",
    "options": [
      "water",
      "advice",
      "apple",
      "rice"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which noun is uncountable?",
    "options": [
      "chair",
      "coin",
      "milk",
      "pen"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Choose the collective noun.",
    "options": [
      "team",
      "quickly",
      "blue",
      "run"
    ],
    "answer": 0
  },
  {
    "type": "mcq",
    "question": "Which is a compound noun?",
    "options": [
      "sunlight",
      "happy",
      "beauty",
      "decide"
    ],
    "answer": 0
  },
  {
    "type": "mcq",
    "question": "Which noun is concrete?",
    "options": [
      "honesty",
      "freedom",
      "table",
      "kindness"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which noun is abstract?",
    "options": [
      "window",
      "courage",
      "pencil",
      "stone"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "What is the noun form of 'happy'?",
    "options": [
      "happiness",
      "happily",
      "happier",
      "happen"
    ],
    "answer": 0
  },
  {
    "type": "mcq",
    "question": "What is the noun form of 'decide'?",
    "options": [
      "decisive",
      "decision",
      "decidingly",
      "decided"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct word: I have ___ friends.",
    "options": [
      "much",
      "many",
      "little",
      "any"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct word: There isn't ___ sugar.",
    "options": [
      "many",
      "few",
      "much",
      "several"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Choose the correct word: Would you like ___ tea?",
    "options": [
      "some",
      "many",
      "few",
      "a"
    ],
    "answer": 0
  },
  {
    "type": "mcq",
    "question": "Choose the correct word: I don't have ___ money.",
    "options": [
      "some",
      "any",
      "many",
      "few"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct phrase.",
    "options": [
      "a few water",
      "a little books",
      "a few books",
      "many milk"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "What is the plural of 'child'?",
    "options": [
      "childs",
      "childes",
      "children",
      "childrens"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "What is the plural of 'tooth'?",
    "options": [
      "tooths",
      "teeth",
      "toothes",
      "tooth"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "What is the plural of 'city'?",
    "options": [
      "citys",
      "cities",
      "cityes",
      "city"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "What is the plural of 'woman'?",
    "options": [
      "womans",
      "women",
      "womens",
      "womanes"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Which noun is feminine?",
    "options": [
      "king",
      "uncle",
      "queen",
      "actor"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which noun is masculine?",
    "options": [
      "mother",
      "sister",
      "brother",
      "aunt"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which is a singular noun?",
    "options": [
      "geese",
      "people",
      "mouse",
      "children"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which is a plural noun?",
    "options": [
      "leaf",
      "feet",
      "child",
      "woman"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct sentence.",
    "options": [
      "She have many book.",
      "She has many books.",
      "She has much books.",
      "She have much books."
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct word: How ___ water do you need?",
    "options": [
      "many",
      "much",
      "few",
      "several"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct word: There are ___ students in class.",
    "options": [
      "much",
      "little",
      "many",
      "any"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which is an irregular plural?",
    "options": [
      "cars",
      "pens",
      "mice",
      "doors"
    ],
    "answer": 2
  },
  {
    "type": "mcq",
    "question": "Which is formed from an adjective?",
    "options": [
      "darkness",
      "teacher",
      "movement",
      "arrival"
    ],
    "answer": 0
  },
  {
    "type": "mcq",
    "question": "Which is formed from a verb?",
    "options": [
      "beautiful",
      "agreement",
      "blue",
      "wide"
    ],
    "answer": 1
  },
  {
    "type": "mcq",
    "question": "Choose the correct sentence.",
    "options": [
      "I need an information.",
      "I need some information.",
      "I need many information.",
      "I need informations."
    ],
    "answer": 1
  },
  {
    "type": "written",
    "question": "Explain the difference between proper nouns and common nouns, and give two examples of each."
  },
  {
    "type": "written",
    "question": "Explain the difference between countable and uncountable nouns."
  },
  {
    "type": "written",
    "question": "Write three collective nouns and use one in a sentence."
  },
  {
    "type": "written",
    "question": "Give two examples of compound nouns and explain how they are formed."
  },
  {
    "type": "written",
    "question": "Explain the difference between concrete and abstract nouns with examples."
  },
  {
    "type": "written",
    "question": "Write the noun forms of the adjectives happy, kind, and dark."
  },
  {
    "type": "written",
    "question": "Write the noun forms of the verbs decide, agree, and develop."
  },
  {
    "type": "written",
    "question": "Explain the use of some and any, giving one example of each."
  },
  {
    "type": "written",
    "question": "Explain the difference between much, many, a few, and a little."
  },
  {
    "type": "written",
    "question": "Write five irregular plural nouns and use two in sentences."
  }
];
